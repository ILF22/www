Encender el servidor:
__________________________________________________

1) Mediante el cmd ir a la carpeta 
  c:\xampp\htdocs\proyectoFinDeCursoForoEducativo\wsChat\server\bin y escribir lo siguiente:

    "php chat-server.php"


Conexión del cliente:
__________________________________________________

1) Abrir http://localhost/proyectoFinDeCursoForoEducativo/wsChat/client/